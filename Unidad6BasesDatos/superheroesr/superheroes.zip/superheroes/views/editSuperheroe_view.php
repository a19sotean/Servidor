<!doctype html>
    <html lang="es">
        <head> 
            <meta charset="UTF-8">
            <meta name="author" content="Rubén Ramírez Rivera">
            <title>Modificar Heroe</title>
        </head>
        <body>
            <h1>Modificar Heroe</h1>
            <form action="" method="post">
                <label>Nombre: <input type="text" placeholder="Nombre" name="nombre"></label><br><br>
                <label>Velocidad: <input type="number" placeholder="2" name="velocidad"></label><br><br>
                <input type="submit" value="Modificar Heroe">  <input type="submit" name="volver" value="Volver">
            </form>
        </body>
    </html>