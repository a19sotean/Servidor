<!doctype html>
    <html lang="es">
        <head> 
            <meta charset="UTF-8">
            <meta name="author" content="Rubén Ramírez Rivera">
            <title>Hola Mundo</title>
        </head>
        <body>
            <noscript>
                <p>Bienvenido a Mi Sitio</p>
                <p>La página que estás viendo requiere para su funcionamiento el uso de JavaScript.
                Si lo has deshabilitado intencionadamente, por favor vuelve a activarlo.</p>
            </noscript>
            <h1>Hola cabesa</h1>
        </body>
    </html>