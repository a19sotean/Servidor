<?php
define("DBHOST",    "localhost");
define("DBUSER",    "root");
define("DBPASS",    "");
define("DBNAME",    "superheroes");
define("DBPORT",    3306);

define("DIRBASEURL", "/superheroes/public/index.php");
define("DIRPUBLIC", "/superheroes/public");

define("SHTOSHOW", 5);
?>